import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-component',
  //templateUrl: './my-component.component.html',
  template:`
  
    <div class="container">
    <h2 class="alert alert-success mt-4">My Component</h2>
    <h1>Welcome Hello Angular!!</h1>

    <button class="{{btnColor}}">{{title}}</button>
    {{data}}-{{title}}
    </div>
  `,
  styleUrls: ['./my-component.component.css']
})



export class MyComponentComponent implements OnInit {

  data=123;
  title="Hello";

  btnColor="btn btn-success";

  constructor() { }

  ngOnInit(): void {
  }

}
